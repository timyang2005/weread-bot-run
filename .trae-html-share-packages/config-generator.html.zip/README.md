# WeRead Bot: 微信读书阅读机器人

[![Auto Reading Bot](https://img.shields.io/github/actions/workflow/status/funnyzak/weread-bot/auto-reading.yml?style=flat-square&label=Auto%20Reading)](https://github.com/funnyzak/weread-bot/actions/workflows/auto-reading.yml)
[![Docker Tags](https://img.shields.io/docker/v/funnyzak/weread-bot?sort=semver&style=flat-square&label=docker%20image)](https://hub.docker.com/r/funnyzak/weread-bot/)
[![Commit activity](https://img.shields.io/github/commit-activity/m/funnyzak/weread-bot?style=flat-square)](https://hub.docker.com/r/funnyzak/weread-bot/)
[![Python](https://img.shields.io/badge/python-3.9+-blue?style=flat-square)](https://www.python.org/)
[![GitHub license](https://img.shields.io/github/license/funnyzak/weread-bot?style=flat-square)](https://github.com/funnyzak/weread-bot/blob/main/LICENSE)

WeRead Bot 是一个易用的微信读书自动阅读机器人，通过模拟真实用户阅读行为来积累阅读时长，支持多用户、多种运行模式（立即执行、定时任务、守护进程）、执行历史和多平台通知，适用于需要提升微信读书等级或完成阅读任务的用户场景。

感谢 [findmover/wxread](https://github.com/findmover/wxread) 提供思路和部分代码支持。

## 适合哪些用户

- 想在本地先快速跑通一个账号的个人用户
- 想用 `config.yaml` 管理参数、通知和定时任务的用户
- 需要同时维护多个微信读书账号的用户
- 想通过 Docker 或 GitHub Actions 长期自动执行的用户
- 希望在运行前先做只读诊断、运行后保留执行历史的用户

## 快速选择

| 你的场景 | 推荐入口 |
|--------|----------|
| 先跑通单账号 | [快速开始](#快速开始) |
| 需要最小化配置说明 | [配置说明](#配置说明) |
| 需要多个账号 | [多用户配置](#多用户配置) |
| 想用 GitHub Actions | [方式四：GitHub Actions 云端运行](#方式四github-actions-云端运行) |
| 想用 Docker | [方式六：Docker 方式运行](#方式六docker-方式运行) |
| 想先排错 | [方式五：不同运行模式](#方式五不同运行模式) |
| 想深入了解抓包和高级能力 | [抓包配置详解](#抓包配置详解) / [高级功能](#高级功能) |

## 首次使用建议

- 先准备一份可用的微信读书 cURL 请求，再开始配置
- 初次运行建议先执行 `--validate-config` 和 `--dry-run`
- 如果你的系统没有 `python` 命令，请把文档中的 `python` 替换为 `python3`

建议第一次执行时使用以下顺序：

```bash
python weread-bot.py --validate-config --config config.yaml
python weread-bot.py --dry-run --config config.yaml
python weread-bot.py --show-last-run --config config.yaml
```

## 核心功能

- ⏰ **智能延迟**：支持启动随机延迟，有效防止固定启动时间特征识别
- 📚 **灵活阅读**：支持时长区间配置（如 30-90 分钟随机），模拟真实阅读习惯
- 👥 **多用户支持**：支持多个微信读书账号执行，可配置最大并发数并为每个用户独立定制策略
- 🎲 **多种阅读模式**：智能随机、顺序阅读、纯随机三种模式，满足不同使用场景
- 🤖 **高级行为模拟**：模拟真实用户阅读行为，包括阅读速度变化、中途休息等
- ⚙️ **多样化配置**：支持配置文件、环境变量、命令行参数三种设置方式，灵活适配各种部署环境
- 📊 **详细统计报告**：提供完整的阅读数据、成功率统计和多维度分析
- 📱 **多平台消息推送**：支持 PushPlus、Telegram、WxPusher、Apprise、Bark、Ntfy、飞书、企业微信、钉钉、Gotify、Server酱³、PushDeer 等通知服务
- 🔧 **智能配置解析**：自动从 CURL 命令提取请求数据、headers 和 cookies，无需手动配置
- 🎯 **精准请求模拟**：使用真实抓包数据，动态生成签名和校验，大幅提高成功率
- 🕐 **灵活定时任务**：支持 cron 表达式定时执行，可自定义执行频率和时间
- 🔄 **守护进程模式**：支持长期运行，自动管理会话间隔，每日会话数量可控
- 🐳 **容器化部署**：提供 Docker 镜像，支持 Docker Compose 一键部署
- ⚡ **云端自动化**：完美支持 GitHub Actions，实现免服务器自动阅读任务
- 🎨 **配置生成器**：提供在线配置生成器，可视化界面生成配置文件，简化配置过程

## 运行预览

<img src="https://raw.githubusercontent.com/funnyzak/weread-bot/refs/heads/main/.github/assets/preview.png" alt="运行预览" style="filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2)); border-radius: 8px;"/>

## 快速开始

### 方式一：直接运行（推荐）

```bash
# 1. 下载文件
wget https://raw.githubusercontent.com/funnyzak/weread-bot/refs/heads/main/weread-bot.py
wget https://raw.githubusercontent.com/funnyzak/weread-bot/refs/heads/main/requirements.txt

# 2. 安装依赖
pip install -r requirements.txt

# 3. 设置环境变量
# 设置CURL命令文件路径（推荐）
export WEREAD_CURL_BASH_FILE_PATH="curl_command.txt"
# 或 设置 CURL命令字符串
export WEREAD_CURL_STRING="curl 'https://weread.qq.com/web/book/read' -H 'cookie: wr_skey=user1_key; ...' --data-raw '{...}'"

# 4. 可选配置
export TARGET_DURATION="30-50"        # 目标阅读时长（分钟），此为 30 到 50 分钟随机
export READING_MODE="smart_random"    # 阅读模式
export PUSHPLUS_TOKEN="your_token"    # PushPlus通知token（如需通知）

# 5. 运行程序
python weread-bot.py
```

> 请将第 3 步中的 `curl_command.txt` 替换为实际保存CURL命令的文件路径。获取CURL命令详见[抓包配置详解](#🔧-抓包配置详解)

### 方式二：配置文件运行

```bash
# 1. 下载配置模板
wget https://raw.githubusercontent.com/funnyzak/weread-bot/refs/heads/main/config.yaml.example

# 2. 创建配置文件
cp config.yaml.example config.yaml

# 3. 编辑配置文件
vim config.yaml

# 4. 运行程序
python weread-bot.py --config config.yaml
```
> 你可以访问： https://weread.gh.yycc.dev/config-generator.html ，通过图形界面生成配置文件

### 方式三：多用户运行

```bash
# 1. 下载配置模板
wget https://raw.githubusercontent.com/funnyzak/weread-bot/refs/heads/main/config.yaml.example

# 2. 创建多用户配置文件进行配置
cp config.yaml.example multiuser-config.yaml

# 3. 为每个用户准备CURL文件
echo "curl 'https://weread.qq.com/web/book/read' -H 'cookie: wr_skey=user1_key; ...' --data-raw '{...}'" > user1_curl.txt
echo "curl 'https://weread.qq.com/web/book/read' -H 'cookie: wr_skey=user2_key; ...' --data-raw '{...}'" > user2_curl.txt

# 5. 编辑配置文件
vim multiuser-config.yaml

# 6. 运行多用户会话
python weread-bot.py --config multiuser-config.yaml
```

> - 也可以设置 `WEREAD_CURL_STRING`，用至少两个空行分隔多段 curl，每段对应一个用户；名称将自动生成为 `env_user_1` 等。

### 方式四：GitHub Actions 云端运行

```bash
# 1. Fork 本项目到你的 GitHub 账户
# 2. 在仓库 Settings → Secrets 中配置必要的环境变量
# 3. 在 Actions 页面手动触发或设置定时运行
```

> **详细配置指南**: [GitHub Actions 自动阅读配置指南](https://github.com/funnyzak/weread-bot/blob/main/docs/github-action-autoread-guide.md)
> 工作流默认会把 `logs/weread.log` 和 `logs/run-history.json` 作为 artifact 上传，便于回看最近执行记录。

### 方式五：不同运行模式

```bash
# 立即执行（默认）
python weread-bot.py

# 定时执行
python weread-bot.py --mode scheduled

# 守护进程模式
python weread-bot.py --mode daemon

# 详细日志输出
python weread-bot.py --verbose

# 仅校验配置与CURL
python weread-bot.py --validate-config --config config.yaml

# 输出运行诊断信息，不发起阅读请求
python weread-bot.py --dry-run --config config.yaml

# 查看最近一次真实执行结果
python weread-bot.py --show-last-run --config config.yaml

# 查看所有可用命令
python weread-bot.py --help
```

说明：

- `--validate-config` 会输出用户数量、用户级 `CURL` 来源、时间策略覆盖情况和全局/用户配置差异摘要。
- `--dry-run` 会在 `--validate-config` 的基础上继续输出通知触发配置、通道就绪状态、缺失字段和禁用通道摘要，但不会真正发起阅读请求。
- `--show-last-run` 只读取 `history.file` 指向的本地历史文件，输出最近一次真实执行摘要后退出，不会初始化阅读会话。
- 真实执行结束后，如 `history.enabled=true`，程序会把最近执行摘要写入默认文件 `logs/run-history.json`。
- 历史记录只保存时间、状态、用户数、阅读统计和失败分类等摘要，不会保存 Cookie、请求头或原始 CURL。
- 如果 `curl_config.users[].reading_overrides` 中存在不支持的键，程序会直接提示对应配置路径。
- 如果 `curl_config.users[].cookie_refresh_ql` 不是布尔值，程序会直接提示对应配置路径。

### 方式六：Docker 方式运行

使用一行命令单次运行：

```bash
docker run -d --name weread-bot \
  --rm \
  -v /path/to/curl_command.txt:/app/curl_command.txt:ro \
  -e TZ="Asia/Shanghai" \
  -e WEREAD_CURL_BASH_FILE_PATH="/app/curl_command.txt" \
  -e TARGET_DURATION="30-50" \
  -e READING_MODE="smart_random" \
  -e PUSHPLUS_TOKEN="your_token" \
  funnyzak/weread-bot:latest
```

> 更多 Docker 方式运行方式，详见 [Docker部署](#docker部署)。

## 配置说明

配置项可通过环境变量或配置文件设置，优先级为：环境变量 > 配置文件 > 程序默认值。 配置文件模板见 [`config.yaml.example`](https://raw.githubusercontent.com/funnyzak/weread-bot/refs/heads/main/config.yaml.example)。

### 配置生成器（推荐新手）

使用在线配置生成器，通过可视化界面生成配置文件：

```bash
# 访问在线配置生成器
open https://weread.gh.yycc.dev/config-generator.html

# 或本地运行配置生成器
wget https://raw.githubusercontent.com/funnyzak/weread-bot/refs/heads/main/config-generator.html
open config-generator.html
```

**在线访问地址：**
- 🌐 **配置生成器**: https://weread.gh.yycc.dev/config-generator.html
- 📖 **项目文档**: https://weread.gh.yycc.dev/

### 必需配置

如果 **未使用配置文件配置**，必须通过环境变量参数提供以下配置：

| 配置项 | 环境变量 | 说明 |
|--------|----------|------|
| CURL配置 | `WEREAD_CURL_STRING` 或 `WEREAD_CURL_BASH_FILE_PATH` | 从微信读书抓包得到的curl命令或命令文件路径 |

- `WEREAD_CURL_STRING`：此环境变量适合在 青龙等面板、GitHub Actions 中直接创建环境变量，内容为完整的CURL命令字符串
- `WEREAD_CURL_BASH_FILE_PATH`：此环境变量适合在本地或Docker中使用，内容为保存CURL命令的文件路径

> 获取CURL命令详见[抓包配置详解](#抓包配置详解)

### 多用户配置

支持通过配置文件配置多个用户的CURL命令和个性化参数，适合需要同时管理多个微信读书账号的场景。若无法写入文件（如 GitHub Actions Secrets），可使用 `WEREAD_CURL_STRING` 放置多段 curl，每段之间至少留出 **两个空行**，程序会自动拆分为多个用户（名称自动生成）。

| 配置项 | 配置文件路径 | 说明 |
|--------|-------------|------|
| 多用户模式 | `curl_config.users` | 配置多个用户的CURL文件和个性化参数 |
| 用户名称 | `curl_config.users[].name` | 用户标识名称 |
| CURL文件 | `curl_config.users[].file_path` | 用户专属的CURL文件路径 |
| Cookie刷新QL覆盖 | `curl_config.users[].cookie_refresh_ql` | 用户级 Cookie 刷新 `ql` 开关，未设置时沿用全局值 |
| 个性化配置 | `curl_config.users[].reading_overrides` | 用户特定的阅读参数覆盖 |

`curl_config.users[].reading_overrides` 当前支持的键：

- `mode`
- `target_duration`
- `reading_interval`
- `use_curl_data_first`
- `fallback_to_config`

如果填写了其他键，`--validate-config` 和 `--dry-run` 会直接报出具体配置路径。

`curl_config.users[].cookie_refresh_ql` 仅支持布尔值：

- `true`: 当前用户刷新 Cookie 时使用 `"ql": true`
- `false`: 当前用户刷新 Cookie 时使用 `"ql": false`
- 不填写: 沿用全局 `hack.cookie_refresh_ql`


### 应用配置

| 配置项 | 环境变量 | 默认值 | 说明 |
|--------|----------|--------|------|
| 启动模式 | `STARTUP_MODE` | `immediate` | immediate/scheduled/daemon |
| 启动延迟 | `STARTUP_DELAY` | `1-10` | 启动随机延迟（秒） |
| 最大并发用户 | `MAX_CONCURRENT_USERS` | `1` | 多用户模式下同时执行的账号数量 |

> `config.yaml.example` 中给出了更保守的示例值（如 `startup_delay: "60-300"`），用于降低固定启动特征；上表列出的是程序内置默认值。

### 阅读配置

| 配置项 | 环境变量 | 默认值 | 说明 |
|--------|----------|--------|------|
| 阅读模式 | `READING_MODE` | `smart_random` | smart_random/sequential/pure_random |
| 目标时长 | `TARGET_DURATION` | `60-70` | 目标阅读时长（分钟） |
| 阅读间隔 | `READING_INTERVAL` | `25-35` | 每次请求间隔（秒） |
| 书籍连续性 | `BOOK_CONTINUITY` | `0.8` | 继续当前书籍的概率（0-1） |
| 章节连续性 | `CHAPTER_CONTINUITY` | `0.7` | 顺序阅读章节的概率（0-1） |

### 人类行为模拟配置

| 配置项 | 环境变量 | 默认值 | 说明 |
|--------|----------|--------|------|
| 行为模拟 | `HUMAN_SIMULATION_ENABLED` | `false` | 是否启用人类行为模拟 |
| 阅读速度变化 | `READING_SPEED_VARIATION` | `true` | 是否变化阅读速度 |
| 休息概率 | `BREAK_PROBABILITY` | `0.1` | 中途休息概率（0-1） |
| 休息时长 | `BREAK_DURATION` | `10-20` | 休息时长（秒） |
| User-Agent轮换 | `ROTATE_USER_AGENT` | `false` | 是否轮换User-Agent |

> 示例配置和 GitHub Actions 场景可能会覆盖这些默认值；以上为未提供配置时的程序内置默认值。

### 网络配置

| 配置项 | 环境变量 | 默认值 | 说明 |
|--------|----------|--------|------|
| 超时时间 | `NETWORK_TIMEOUT` | `30` | 网络请求超时（秒） |
| 重试次数 | `RETRY_TIMES` | `3` | 失败重试次数 |
| 重试延迟 | `RETRY_DELAY` | `5-15` | 重试间隔（秒） |
| 频率限制 | `RATE_LIMIT` | `10` | 请求频率（次/分钟） |

> **提示**：`RATE_LIMIT` 现在会在内部以异步速率限制器落实到每一次 API 调用，`RETRY_DELAY` 则作为指数退避区间使用。合理配置这两个参数可以在稳定性与速度之间取得平衡，避免在长时间守护进程中被判定为异常流量。

### Hack配置

Hack配置用于解决特殊兼容性问题，包含以下选项：

| 配置项 | 环境变量 | 默认值 | 说明 |
|--------|----------|--------|------|
| Cookie刷新QL属性 | `HACK_COOKIE_REFRESH_QL` | `false` | Cookie刷新时ql属性值设置 |

**详细说明：**
- `cookie_refresh_ql`: 控制Cookie刷新请求中的`ql`参数值，作为全局默认值
  - `false` (默认): 使用`"ql": false`
  - `true`: 使用`"ql": true`
- 多用户模式下，可通过 `curl_config.users[].cookie_refresh_ql` 为单个用户覆盖该值
- 环境变量 `HACK_COOKIE_REFRESH_QL` 只能设置全局默认值，不能为不同用户分别设置
- 根据不同用户的环境，可能需要设置为True或False来确保cookie刷新正常工作
- 如果遇到cookie刷新失败的问题，可以尝试切换此配置的值

**使用场景：**
```yaml
# config.yaml 示例
hack:
  cookie_refresh_ql: false  # 全局默认值

curl_config:
  users:
    - name: "user1"
      file_path: "user1_curl.txt"
      cookie_refresh_ql: true  # 仅覆盖该用户
```

### 执行历史配置

程序默认会把最近真实执行结果写入本地 JSON 文件，便于排查最近一次任务状态和失败类型。

| 配置项 | 环境变量 | 默认值 | 说明 |
|--------|----------|--------|------|
| 历史开关 | `HISTORY_ENABLED` | `true` | 是否启用执行历史持久化 |
| 历史文件 | `HISTORY_FILE` | `logs/run-history.json` | 历史记录输出路径 |
| 保留条数 | `HISTORY_MAX_ENTRIES` | `50` | 仅保留最近 N 条真实执行记录 |
| 异常落盘 | `HISTORY_PERSIST_RUNTIME_ERROR` | `true` | 真实执行运行时异常时是否追加失败记录 |

示例：

```yaml
history:
  enabled: true
  file: "logs/run-history.json"
  max_entries: 50
  persist_runtime_error: true
```

说明：

- `--validate-config` 与 `--dry-run` 不会写入历史，避免污染真实执行结果。
- 历史文件内容损坏时，程序会记录警告并回退为空历史，不会阻断主流程。
- 历史记录不会保存敏感请求数据，例如 Cookie、请求头和原始 CURL。

### 使用建议

- **并发控制**：`MAX_CONCURRENT_USERS` 建议从 1 开始，根据机器性能和账号风险逐步提升；并发越高，对网络和请求频控要求越严格。
- **速率限制**：`RATE_LIMIT` 与并发密切相关，若提升并发，请同步调低单会话频率或增大 `reading.reading_interval`，保持整体 QPS 可控。
- **定时任务时区**：scheduled 模式完全按照 `TIMEZONE` 计算，跨地区运行前请先确认服务器系统时区，必要时设置为 UTC 并统一换算。
- **守护模式节奏**：`daemon.session_interval` 不宜过小，建议 >=120 分钟，并结合 `max_daily_sessions` 控制每日触发次数，避免频繁刷新被识别。

### 通知配置

| 配置项 | 环境变量 | 默认值 | 说明 |
|--------|----------|--------|------|
| 通知开关 | `NOTIFICATION_ENABLED` | `true` | 是否启用通知 |
| 包含统计 | `INCLUDE_STATISTICS` | `true` | 是否包含详细统计 |
| 仅失败通知 | `NOTIFICATION_ONLY_ON_FAILURE` | `false` | 启用后仅在失败或异常时推送 |

**注意：通知配置采用多通道模式，支持同时启用多个通知服务**

**触发策略示例：**

```yaml
notification:
  triggers:
    session_success: true
    session_failure: true
    multi_user_summary: true
    runtime_error: true
    general: true
  only_on_failure: false
```

将 `only_on_failure` 设为 `true` 即等价于关闭 `session_success` 和 `multi_user_summary`，从而在单用户、多用户场景下都实现“仅失败通知”。如需更细粒度的控制，可单独调整 `triggers` 中的对应事件。

| 通知服务 | 配置参数 | 环境变量 | 说明 |
|---------|---------|----------|------|
| PushPlus | `token` | `PUSHPLUS_TOKEN` | PushPlus推送token |
| Telegram | `bot_token` | `TELEGRAM_BOT_TOKEN` | Telegram机器人token |
| | `chat_id` | `TELEGRAM_CHAT_ID` | Telegram聊天ID |
| | `proxy.http` | `HTTP_PROXY` | HTTP代理地址 |
| | `proxy.https` | `HTTPS_PROXY` | HTTPS代理地址 |
| WxPusher | `spt` | `WXPUSHER_SPT` | WxPusher SPT |
| Apprise | `url` | `APPRISE_URL` | Apprise通知URL |
| Bark | `server` | `BARK_SERVER` | Bark推送服务器地址 |
| | `device_key` | `BARK_DEVICE_KEY` | Bark设备密钥 |
| | `sound` | `BARK_SOUND` | Bark通知音效 |
| Ntfy | `server` | `NTFY_SERVER` | Ntfy服务器地址 |
| | `topic` | `NTFY_TOPIC` | Ntfy推送主题 |
| | `token` | `NTFY_TOKEN` | Ntfy访问令牌（可选） |
| 飞书 | `webhook_url` | `FEISHU_WEBHOOK_URL` | 飞书机器人Webhook URL |
| | `msg_type` | `FEISHU_MSG_TYPE` | 消息类型：text/rich_text |
| 企业微信 | `webhook_url` | `WEWORK_WEBHOOK_URL` | 企业微信机器人Webhook URL |
| | `msg_type` | `WEWORK_MSG_TYPE` | 消息类型：text/markdown/news |
| 钉钉 | `webhook_url` | `DINGTALK_WEBHOOK_URL` | 钉钉机器人Webhook URL |
| | `msg_type` | `DINGTALK_MSG_TYPE` | 消息类型：text/markdown/link |
| Gotify | `server` | `GOTIFY_SERVER` | Gotify服务器地址 |
| | `token` | `GOTIFY_TOKEN` | Gotify应用令牌 |
| | `priority` | `GOTIFY_PRIORITY` | 消息优先级（1-10） |
| | `title` | `GOTIFY_TITLE` | 消息标题 |
| Server酱³ | `uid` | `SERVERCHAN3_UID` | Server酱³ UID |
| | `sendkey` | `SERVERCHAN3_SENDKEY` | Server酱³ SendKey |
| | `tags` | `SERVERCHAN3_TAGS` | 标签（可选，用|分隔） |
| | `short` | `SERVERCHAN3_SHORT` | 简短描述（可选） |
| PushDeer | `pushkey` | `PUSHDEER_PUSHKEY` | PushDeer PushKey |
| | `type` | `PUSHDEER_TYPE` | 消息类型：text/markdown |

### 通知方式详细说明

#### PushPlus
- 获取方式：访问 [pushplus.plus](https://www.pushplus.plus/) 注册获取token
- 配置：设置 `PUSHPLUS_TOKEN` 环境变量

#### Telegram
- 获取方式：
  1. 与 @BotFather 对话创建机器人获取 bot_token
  2. 与 @userinfobot 对话获取 chat_id
- 配置：设置 `TELEGRAM_BOT_TOKEN` 和 `TELEGRAM_CHAT_ID`
- 代理：支持HTTP/HTTPS代理

#### WxPusher
- 获取方式：访问 [wxpusher.zjiecode.com](https://wxpusher.zjiecode.com/) 获取SPT
- 配置：设置 `WXPUSHER_SPT` 环境变量

#### Apprise（支持多种服务）
- 支持：Discord、Slack、Email、企业微信等数十种服务
- 配置：设置 `APPRISE_URL`，格式如：
  - Discord: `discord://webhook_id/webhook_token`
  - Email: `mailto://user:pass@domain.com`
  - 自部署 Apprise 服务器: `apprises://your_apprise_server.com/your_apprise_token/?tags=pro`
  - 更多格式见：[Apprise文档](https://github.com/caronc/apprise)

#### Bark（iOS推送）
- 获取方式：iOS App Store下载Bark应用，获取设备Key
- 配置：设置 `BARK_SERVER`（默认：https://api.day.app）和 `BARK_DEVICE_KEY`
- 音效：可选设置 `BARK_SOUND`

#### Ntfy（开源推送）
- 获取方式：使用公共服务 [ntfy.sh](https://ntfy.sh) 或自建服务
- 配置：设置 `NTFY_SERVER` 和 `NTFY_TOPIC`
- 私有主题：可选设置 `NTFY_TOKEN`

#### 飞书（Lark）
- 获取方式：
  1. 在飞书群聊中添加机器人
  2. 选择"自定义机器人"
  3. 获取Webhook URL
- 配置：设置 `FEISHU_WEBHOOK_URL`
- 消息格式：支持 `text`（纯文本）和 `rich_text`（富文本）
- 示例：`https://open.feishu.cn/open-apis/bot/v2/hook/your_webhook_token`

#### 企业微信
- 获取方式：
  1. 在企业微信群聊中添加机器人
  2. 选择"自定义机器人"
  3. 获取Webhook URL
- 配置：设置 `WEWORK_WEBHOOK_URL`
- 消息格式：支持 `text`（纯文本）、`markdown`（Markdown格式）、`news`（图文消息）
- 示例：`https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=your_webhook_key`

#### 钉钉
- 获取方式：
  1. 在钉钉群聊中添加机器人
  2. 选择"自定义机器人"
  3. 获取Webhook URL
- 配置：设置 `DINGTALK_WEBHOOK_URL`
- 消息格式：支持 `text`（纯文本）、`markdown`（Markdown格式）、`link`（链接消息）
- 示例：`https://oapi.dingtalk.com/robot/send?access_token=your_access_token`

#### Gotify（开源推送服务）
- 获取方式：
  1. 部署 Gotify 服务器（自建或使用公共服务）
  2. 创建应用并获取应用令牌
  3. 配置服务器地址和令牌
- 配置：设置 `GOTIFY_SERVER` 和 `GOTIFY_TOKEN`
- 优先级：可选设置 `GOTIFY_PRIORITY`（1-10，数字越大优先级越高）
- 标题：可选设置 `GOTIFY_TITLE` 自定义消息标题
- 示例：`https://gotify.example.com` + `your_app_token`
- 官网：https://gotify.net/

#### Server酱³（Server酱）
- 获取方式：
  1. 访问 [Server酱³](https://sc3.ft07.com/) 注册账号
  2. 获取 UID 和 SendKey
- 配置：设置 `SERVERCHAN3_UID` 和 `SERVERCHAN3_SENDKEY`
- 标签：可选设置 `SERVERCHAN3_TAGS`，支持多个标签用|分隔
- 简短描述：可选设置 `SERVERCHAN3_SHORT`，用于显示简要信息
- 官网：https://sc3.ft07.com/
- 文档：https://doc.sc3.ft07.com/

#### PushDeer（开源推送服务）
- 获取方式：
  1. 访问 [PushDeer](https://www.pushdeer.com/) 或下载 iOS App
  2. 注册账号并获取 PushKey
- 配置：设置 `PUSHDEER_PUSHKEY`
- 代理：支持HTTP/HTTPS代理（可选）
- 消息格式：支持 纯文本和Markdown
- 官网：https://www.pushdeer.com/
- 文档：https://www.pushdeer.com/official.html

#### 自定义通知服务

如果没有找到合适的通知服务，可以通过 Apprise 配置需要的通知服务，如 **Email** 通知设置格式 `mailto://user:pass@domain.com`。配置请参考 [Apprise文档](https://github.com/caronc/apprise)。

### 定时任务配置（scheduled模式）
| 配置项 | 环境变量 | 默认值 | 说明 |
|--------|----------|--------|------|
| 定时开关 | `SCHEDULE_ENABLED` | `false` | 是否启用定时任务 |
| Cron表达式 | `CRON_EXPRESSION` | `0 */2 * * *` | 定时执行表达式 |
| 时区 | `TIMEZONE` | `Asia/Shanghai` | 时区设置 |

> **提示**：Scheduled 模式由 `croniter` + `ZoneInfo` 驱动，能够精准地按照配置时区计算下一次运行时间，无需再额外处理夏令时或跨地区偏移。

### 守护进程配置（daemon模式）
| 配置项 | 环境变量 | 默认值 | 说明 |
|--------|----------|--------|------|
| 守护进程开关 | `DAEMON_ENABLED` | `false` | 是否启用守护进程 |
| 会话间隔 | `SESSION_INTERVAL` | `120-180` | 会话间隔时间（分钟） |
| 每日最大会话数 | `MAX_DAILY_SESSIONS` | `12` | 每日最大执行次数 |

## 运行模式详解

### 立即执行模式（immediate）
```bash
python weread-bot.py
# 或
python weread-bot.py --mode immediate
```
- 程序启动后立即开始一次阅读会话
- 完成目标时长后自动退出
- 适合单次使用或手动控制

### 定时执行模式（scheduled）
```bash
python weread-bot.py --mode scheduled
```
配置定时任务：
```yaml
schedule:
  enabled: true
  cron_expression: "0 */2 * * *"    # 每2小时执行一次
  timezone: "Asia/Shanghai"
```
支持的cron表达式示例：
- `"0 */2 * * *"` - 每2小时执行一次
- `"30 9 * * *"` - 每天9:30执行
- `"0 * * * *"` - 每小时执行
- `"0 9,18 * * *"` - 每天9点和18点执行
- `"30 9,18 * * *"` - 每天9:30和18:30执行（多时间点）
- `"0 8,12,18 * * *"` - 每天8:00、12:00、18:00执行

### 守护进程模式（daemon）

```bash
python weread-bot.py --mode daemon
```

配置守护进程：
```yaml
daemon:
  enabled: true
  session_interval: "120-180"       # 会话间隔2-3小时随机
  max_daily_sessions: 12            # 每天最多12次会话
```

- 程序持续运行，自动管理会话间隔
- 支持每日会话次数限制
- 自动处理跨天重置
- 支持优雅关闭（Ctrl+C）

### 最近执行结果查询

```bash
python weread-bot.py --show-last-run --config config.yaml
```

- 仅读取 `history.file` 指向的历史文件
- 没有历史记录时会输出明确提示
- 适合快速确认最近一次真实执行的状态、用户统计和失败分类

## 阅读模式详解

### 智能随机模式（smart_random）

```yaml
reading:
  mode: "smart_random"
  smart_random:
    book_continuity: 0.8          # 80%概率继续当前书籍
    chapter_continuity: 0.7       # 70%概率顺序阅读章节
    book_switch_cooldown: 300     # 换书冷却5分钟
```

- 模拟真实用户的阅读习惯
- 倾向于连续阅读同一本书的连续章节
- 偶尔随机跳转到其他书籍或章节
- 有换书冷却机制，避免频繁切换

### 顺序阅读模式（sequential）

```yaml
reading:
  mode: "sequential"
```

- 按配置的书籍和章节顺序依次阅读
- 读完一本书后自动切换到下一本
- 最符合正常阅读逻辑

### 纯随机模式（pure_random）

```yaml
reading:
  mode: "pure_random"
```

- 完全随机选择书籍和章节
- 每次请求都可能跳转到不同位置
- 最大化随机性，但可能不够自然

## 统计报告示例

### 单用户统计报告

```
📊 微信读书自动阅读统计报告

👤 用户: 用户1
⏰ 开始时间: 2024-01-15 09:30:15
⏱️ 实际阅读: 65分32秒
🎯 目标时长: 65分钟
✅ 成功请求: 328次
❌ 失败请求: 5次
📈 成功率: 98.5%
📚 阅读书籍: 3本
📄 阅读章节: 28个
☕ 休息次数: 12次 (共1256秒)
🚀 平均响应: 1.23秒

🎉 本次阅读任务完成！
```

### 多用户统计报告

```
🎭 多用户阅读会话总结

👥 用户统计:
  📊 总用户数: 3
  ✅ 成功用户: 2 (用户1, 用户3)
  ❌ 失败用户: 1 (用户2)

📖 阅读统计:
  ⏱️ 总阅读时长: 128分45秒
  ✅ 总成功请求: 652次
  ❌ 总失败请求: 12次
  📈 整体成功率: 98.2%

🎉 多用户阅读任务完成！
```

## 抓包配置详解

### 获取CURL命令步骤

1. **打开微信读书网页版**：https://weread.qq.com/
2. **登录账号**：确保已登录微信读书账号
3. **开始阅读**：找一本书开始阅读
4. **打开开发者工具**：按F12或右或者浏览器菜单选择“开发者工具”
5. **翻页**：在阅读页面翻页，模拟正常阅读行为
6. **查找请求**：
   - 切换到 Network（网络）标签
   - 在过滤器中输入 `read`
   - 继续翻页，找到 `https://weread.qq.com/web/book/read` 请求
7. **复制CURL**：
   - 右键该请求
   - 选择 `Copy` → `Copy as cURL (bash)`
8. **保存配置**：将复制的内容保存为环境变量或文件

### 智能数据提取

程序会自动从CURL命令中提取：
- **Headers**：包括 User-Agent、Content-Type、Referer 等
- **Cookies**：包括认证相关的 wr_skey、wr_vid 等
- **请求数据**：包括 appId、书籍ID、章节ID 等真实参数

**示例CURL命令结构**：

```bash
curl 'https://weread.qq.com/web/book/read' \
  -H 'accept: application/json, text/plain, */*' \
  -H 'accept-language: zh-CN,zh;q=0.9,en;q=0.8' \
  -H 'content-type: application/json;charset=UTF-8' \
  -H 'cookie: wr_skey=s_abc123; wr_vid=12345678; ...' \
  -H 'origin: https://weread.qq.com' \
  -H 'referer: https://weread.qq.com/web/reader/...' \
  -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) ...' \
  --data-raw '{"appId":"wb987654321098h765432109","b":"a1b2c3d4e5f6g7h8i9j0k1l","c":"m2n3o4p5q6r7s8t9u0v1w2x","ci":60,"co":123,"sm":"[插图]示例阅读内容","pr":65,"rt":88,"ts":1234567890123,"rn":114,"sg":"abc123def456ghi789jkl012mno345pqr678stu901vwx234yz567890abcdef12","ct":1234567890,"ps":"xxxxxxxxxxxxxxxxxxxxxxxx","pc":"xxxxxxxxxxxxxxxxxxxxxxxx","s":"abc12345"}'
```

### 配置方式选择

**方式1：环境变量（推荐）**

```bash
export WEREAD_CURL_STRING="curl 'https://weread.qq.com/web/book/read' ..."
```

**方式2：文件存储**

```bash
# 保存CURL命令到文件
echo "curl 'https://weread.qq.com/web/book/read' ..." > curl_command.txt
export WEREAD_CURL_BASH_FILE_PATH="curl_command.txt"
```

**方式3：配置文件**

```yaml
curl_config:
  file_path: "curl_command.txt"
```

### 数据提取验证

程序启动时会显示提取结果：

```text
✅ 已从环境变量加载CURL配置
✅ 已使用CURL中的请求数据，包含字段: ['appId', 'b', 'c', 'ci', 'co', 'sm', 'pr', 'rt', 'ts', 'rn', 'sg', 'ct', 'ps', 'pc', 's']
✅ 使用CURL数据作为阅读起点: 书籍 ce032b305a9bc1ce0b0dd2a, 章节 2a3327002582a38a4a932bf
```

## Docker部署

### 运行

```bash
# 运行容器（环境变量方式）
docker run -d \
  -e TZ="Asia/Shanghai" \
  -e WEREAD_CURL_STRING="your_curl_here" \
  -e TARGET_DURATION="60-70" \
  -e PUSHPLUS_TOKEN="your_token" \
  --name weread-bot \
  funnyzak/weread-bot

# 运行容器（配置文件方式）
docker run -d \
  -e TZ="Asia/Shanghai" \
  -v $(pwd)/config.yaml:/app/config.yaml \
  -v $(pwd)/curl_command.txt:/app/curl_command.txt \
  -v $(pwd)/logs:/app/logs \
  --name weread-bot \
  funnyzak/weread-bot

# 守护进程模式
docker run -d \
  -e TZ="Asia/Shanghai" \
  -e WEREAD_CURL_STRING="your_curl_here" \
  -e STARTUP_MODE="daemon" \
  --name weread-daemon \
  funnyzak/weread-bot

# 查看日志
docker logs -f weread-bot
```

### Docker Compose

```yaml
version: '3.8'
services:
  weread-bot:
    image: funnyzak/weread-bot:latest
    container_name: weread-bot
    environment:
      - TZ=Asia/Shanghai
    volumes:
      - ./logs:/app/logs
      - ./config.yaml:/app/config.yaml:ro
      - ./curl_command.txt:/app/curl_command.txt:ro
    restart: unless-stopped
```

运行：

```bash

# 启动服务
docker-compose up -d

# 查看日志
docker-compose logs -f
```

## 高级功能

### 多用户会话管理

```yaml
# 多用户配置结构
curl_config:
  users:
    - name: "用户1"                    # 用户标识名称
      file_path: "user1_curl.txt"      # 用户专属的CURL文件路径
      cookie_refresh_ql: true          # 可选：覆盖全局 hack.cookie_refresh_ql
      reading_overrides:               # 用户特定的阅读参数覆盖（可选）
        target_duration: "45-90"       # 阅读时长
        mode: "smart_random"           # 阅读模式
        reading_interval: "30-48"      # 阅读间隔
        use_curl_data_first: true      # 是否优先使用CURL数据
        fallback_to_config: true       # 是否回退到配置数据
    
    - name: "用户2"
      file_path: "user2_curl.txt"
      reading_overrides:
        target_duration: "30-60"
        mode: "sequential"
        reading_interval: "25-35"
```

**多用户执行特性：**

- **可控并发**：通过 `MAX_CONCURRENT_USERS` 控制同时在线的账号数量，默认1表示顺序执行
- **独立配置**：每个用户可以有不同的阅读策略、时长和 Cookie 刷新 `ql` 开关
- **错误隔离**：单个用户失败不影响其他用户执行
- **统计汇总**：提供单用户和多用户的详细统计报告，包含成功、失败、跳过和失败分类汇总

**配置覆盖优先级：**

1. **用户特定配置** (`reading_overrides` / `curl_config.users[].cookie_refresh_ql`) - 最高优先级
2. **全局配置** (`reading` / `hack.cookie_refresh_ql`) - 默认配置
3. **程序默认值** - 最低优先级

### 智能书籍管理

```yaml
reading:
  # 书籍配置列表
  # 章节索引优先级：配置的索引值 > CURL提取的值 > 自动计算的索引
  books:
    - name: "深度工作"                    # 书籍名称
      book_id: "book_id_1"               # 书籍ID
      chapters:                          # 章节配置，支持新旧两种格式
        # 新格式：包含章节ID和可选的章节索引（推荐）
        - chapter_id: "chapter_1"
          chapter_index: 60              # 可选：微信读书官方章节索引ID
        - chapter_id: "chapter_2"
          chapter_index: 61              # 可选：微信读书官方章节索引ID
        # 旧格式：只有章节ID（向后兼容）
        - "chapter_3"                    # 兼容旧格式，章节索引将自动计算或从CURL提取
    
    - name: "原则"
      book_id: "book_id_2"
      chapters:
        # 也可以使用简化的字段名
        - id: "chapter_a"
          index: 25                      # 使用简化字段名
        # 混合使用新旧格式
        - "chapter_b"                    # 旧格式
  
  # 智能随机策略
  smart_random:
    book_continuity: 0.8          # 书籍连续性
    chapter_continuity: 0.7       # 章节连续性
    book_switch_cooldown: 300     # 换书冷却
```

#### 章节索引配置说明

**什么是章节索引（ci）？**
- 章节索引是微信读书为每个章节分配的专有数字标识符
- 与章节ID（c）不同，章节索引通常是连续的数字（如：60, 61, 62...）

**配置格式：**
1. **新格式（推荐）**：包含章节ID和可选的章节索引
   ```yaml
   - chapter_id: "9bf32f301f9bf31c7ff0a60"
     chapter_index: 60
   ```
   或使用简化字段名：
   ```yaml
   - id: "9bf32f301f9bf31c7ff0a60"
     index: 60
   ```

2. **旧格式（兼容）**：只有章节ID字符串
   ```yaml
   - "9bf32f301f9bf31c7ff0a60"
   ```

**章节索引优先级：**
1. **配置的索引值**：在配置文件中明确指定的 `chapter_index` 或 `index`
2. **CURL提取的值**：从抓取的CURL命令中提取的 `ci` 值
3. **自动计算的索引**：章节在配置列表中的位置（从0开始）

**如何获取章节索引？**
1. 在微信读书网页版翻页时，查看Network请求中的 `ci` 字段值
2. 不同章节的 `ci` 值通常是连续递增的数字

### 高级网络配置

```yaml
network:
  timeout: 30                     # 请求超时
  retry_times: 3                  # 重试次数
  retry_delay: "5-15"            # 重试延迟
  rate_limit: 10                 # 频率限制（请求/分钟）
```

### 多平台通知支持

```yaml
notification:
  enabled: true
  include_statistics: true       # 包含详细统计
  
  # 通知通道配置（支持多个通道同时使用）
  channels:
    # 通道1：PushPlus
    - name: "pushplus"
      enabled: true
      config:
        token: "${PUSHPLUS_TOKEN}"
    
    # 通道2：Telegram
    - name: "telegram"
      enabled: true
      config:
        bot_token: "${TELEGRAM_BOT_TOKEN}"
        chat_id: "${TELEGRAM_CHAT_ID}"
        proxy:
          http: "${HTTP_PROXY}"
          https: "${HTTPS_PROXY}"
    
    # 通道3：WxPusher
    - name: "wxpusher"
      enabled: false
      config:
        spt: "${WXPUSHER_SPT}"
    
    # 通道4：Apprise
    - name: "apprise"
      enabled: false
      config:
        # Apprise通知URL，支持多种服务（如Discord、Slack、Email等）
        # 示例：discord://webhook_id/webhook_token
        # 示例：mailto://user:pass@domain.com
        # 详见：https://github.com/caronc/apprise
        url: "${APPRISE_URL}"
    
    # 通道5：Bark
    - name: "bark"
      enabled: false
      config:
        # Bark服务器地址
        server: "${BARK_SERVER}"     # 如：https://api.day.app
        # 设备Key
        device_key: "${BARK_DEVICE_KEY}"
        # 通知音效（可选）
        sound: "${BARK_SOUND}"
    
    # 通道6：Ntfy
    - name: "ntfy"
      enabled: false
      config:
        # Ntfy服务器地址（默认：https://ntfy.sh）
        server: "${NTFY_SERVER}"     # 如：https://ntfy.sh
        # 主题名称
        topic: "${NTFY_TOPIC}"
        # 访问令牌（可选，用于私有主题）
        token: "${NTFY_TOKEN}"
    
    # 通道7：飞书
    - name: "feishu"
      enabled: false
      config:
        # 飞书机器人Webhook URL
        webhook_url: "${FEISHU_WEBHOOK_URL}"
        # 消息类型：text(纯文本), rich_text(富文本)
        msg_type: "text"
    
    # 通道8：企业微信
    - name: "wework"
      enabled: false
      config:
        # 企业微信机器人Webhook URL
        webhook_url: "${WEWORK_WEBHOOK_URL}"
        # 消息类型：text(纯文本), markdown(Markdown), news(图文)
        msg_type: "text"
    
    # 通道9：钉钉
    - name: "dingtalk"
      enabled: false
      config:
        # 钉钉机器人Webhook URL
        webhook_url: "${DINGTALK_WEBHOOK_URL}"
        # 消息类型：text(纯文本), markdown(Markdown), link(链接)
        msg_type: "text"
    
    # 通道10：Gotify
    - name: "gotify"
      enabled: false
      config:
        # Gotify服务器地址
        server: "${GOTIFY_SERVER}"     # 如：https://gotify.example.com
        # 应用令牌
        token: "${GOTIFY_TOKEN}"
        # 消息优先级（1-10，数字越大优先级越高）
        priority: "${GOTIFY_PRIORITY}"
        # 消息标题（可选）
        title: "${GOTIFY_TITLE}"
```

## 微信读书API字段说明

程序会自动从CURL命令中提取并处理这些字段，无需手动配置：

| 字段 | 示例值 | 说明 | 处理方式 |
|------|--------|------|----------|
| `appId` | `"wb115321887466h953405538"` | 应用唯一标识符 | 从CURL提取，保持不变 |
| `b` | `"241325c071f385dd2417ff2"` | 书籍ID | 智能管理，支持多书籍切换 |
| `c` | `"02e32f0021b02e74f10ece8"` | 章节ID | 智能管理，支持章节跳转 |
| `ci` | `60` | 章节索引 | 智能管理，支持配置和自动计算 |
| `co` | `336` | 内容位置/页码 | 从CURL提取，保持不变 |
| `sm` | `"2　开启你的专注之路有一篇名为《算术"` | 当前阅读内容摘要 | 从CURL提取，保持不变 |
| `pr` | `65` | 页码/段落索引 | 从CURL提取，保持不变 |
| `rt` | `88` | 阅读时长（秒） | 动态计算，模拟真实阅读时间 |
| `ts` | `1727580815581` | 时间戳（毫秒） | 动态生成，包含随机偏移 |
| `rn` | `114` | 随机数/请求编号 | 动态生成随机数 |
| `sg` | `"bfdf7de...e22e724"` | 安全签名 | 动态计算SHA256签名 |
| `ct` | `1727580815` | 时间戳（秒） | 动态生成当前时间 |
| `ps` | `"xxxxxxxx"` | 用户标识符 | 从CURL提取，保持不变 |
| `pc` | `"xxxxxxxx"` | 设备标识符 | 从CURL提取，保持不变 |
| `s` | `"fadcb9de"` | 数据校验和 | 动态计算哈希值 |

### 安全机制
- **签名算法**：使用时间戳、随机数和密钥生成SHA256签名
- **数据校验**：通过特定算法计算请求数据的校验和
- **时间同步**：动态生成符合服务器要求的时间戳
- **Cookie管理**：自动刷新和维护认证Cookie

## 常见问题

### Q: 如何防止被微信识别为机器人？

**A: 内置多层防检测机制：**
- **启动延迟**：默认 1-10 秒随机延迟，避免批量启动特征；可按需调大
- **阅读速度变化**：每30秒调整阅读速度（0.8-1.3倍）
- **中途休息**：默认 10% 概率随机休息 10-20 秒；可按需调大
- **智能换书**：基于概率的书籍和章节切换
- **时间戳随机化**：请求时间包含随机偏移
- **Cookie自动刷新**：维护有效的认证状态

### Q: 程序运行多长时间？

**A: 灵活的时长控制：**
- **默认时长**：60-70分钟随机选择
- **自定义区间**：支持如`"60-120"`的区间配置
- **智能完成**：达到目标时长后自动停止
- **守护模式**：可设置每日最大会话数和间隔时间

### Q: 如何查看运行状态？
**A: 多种监控方式：**
- **实时日志**：详细的运行过程日志
- **进度显示**：当前阅读进度和剩余时间
- **统计报告**：完成后的详细统计信息
- **推送通知**：支持多平台消息推送
- **日志文件**：保存在`logs/weread.log`


### Q: 程序报错"Cookie刷新失败"？
**A: Cookie问题解决：**
- 重新获取最新的CURL命令
- 确保微信读书账号未过期
- 检查网络连接是否正常
- 尝试重启程序让Cookie自动刷新

### Q: 支持多账号同时运行吗？

**A: 支持多用户模式，可通过并发配置灵活执行多个账号：**
```yaml
# 多用户配置方式
curl_config:
  users:
    - name: "账号1"
      file_path: "account1_curl.txt"
      cookie_refresh_ql: true
      reading_overrides:
        target_duration: "45-90"
    - name: "账号2"  
      file_path: "account2_curl.txt"
      cookie_refresh_ql: false
      reading_overrides:
        target_duration: "30-60"
```

**执行特点：**
- 通过 `MAX_CONCURRENT_USERS` 控制是否并发执行（默认1则顺序执行）
- 单个账号失败不影响其他账号
- 每个账号可独立设置 `cookie_refresh_ql`
- 提供详细的多用户统计报告

**传统方式（并行运行）：**
```bash
# 方法1：多个配置文件
python weread-bot.py --config account1.yaml
python weread-bot.py --config account2.yaml
```

### Q: 多用户模式总执行时间是多少？
**A: 执行时间计算：**
- 当 `MAX_CONCURRENT_USERS = 1` 时，总时间≈所有用户阅读时长之和
- 当并发数 > 1 时，总时间≈(总阅读时长 / 并发数) + 少量调度开销
- **优化建议**：根据目标机器性能与风控策略调整并发数与单次时长
- **说明**：适度的并发可以缩短整体运行时间，但请确保网络与账号风险可控

### Q: 某个用户失败了怎么办？
**A: 错误处理机制：**
- **错误隔离**：单个用户失败不影响其他用户执行
- **详细日志**：记录每个用户的执行状态和错误信息
- **继续执行**：失败用户跳过，继续执行下一个用户
- **统计报告**：最终报告中显示成功和失败的用户列表

### Q: 如何调整阅读策略更自然？
**A: 策略优化建议：**
```yaml
# 更保守的策略
human_simulation:
  break_probability: 0.2        # 增加休息频率
  break_duration: "60-300"      # 延长休息时间
reading:
  target_duration: "45-90"      # 缩短单次时长
  smart_random:
    book_continuity: 0.9        # 提高书籍连续性
    chapter_continuity: 0.8     # 提高章节连续性
```

## 性能优化建议

### 网络优化
```yaml
network:
  timeout: 30              # 根据网络情况调整
  retry_times: 3           # 网络不稳定时增加重试
  retry_delay: "5-15"      # 重试间隔
  rate_limit: 8            # 降低请求频率更安全
```

### 行为优化
```yaml
human_simulation:
  break_probability: 0.2   # 提高休息频率
  break_duration: "60-300" # 延长休息时间
  reading_speed_variation: true
```

### 时长策略
```yaml
reading:
  target_duration: "60-90"   # 较短时长更安全
  reading_interval: "30-45"  # 增加请求间隔
```

## 项目文档

- [文档总览](docs/README.md)
- [GitHub Actions 自动阅读配置指南](docs/github-action-autoread-guide.md)

## 安全建议

1. **不要分享CURL命令**：包含个人认证信息
2. **定期更新**：Cookie会过期，需要重新获取
3. **适度使用**：避免过度频繁的阅读行为
4. **监控日志**：关注异常和错误信息
5. **备份配置**：保存有效的配置文件

## 鸣谢

特别感谢以下项目提供的实现参考：

- https://github.com/findmover/wxread

## 免责声明

本项目仅供学习和研究目的，不得用于任何商业活动。用户在使用本项目时应遵守所在地区的法律法规，对于违法使用所导致的后果，本项目及作者不承担任何责任。 本项目可能存在未知的缺陷和风险（包括但不限于账号封禁等），使用者应自行承担使用本项目所产生的所有风险及责任。 作者不保证本项目的准确性、完整性、及时性、可靠性，也不承担任何因使用本项目而产生的任何损失或损害责任。 使用本项目即表示您已阅读并同意本免责声明的全部内容。

## 许可证

MIT License
